# Argo CD 9.4.2 offline vendor bundle

This directory is ready to copy into `eit-sapzora-aws-admins`.

`charts/argo-cd` is the upstream `argo-cd-9.4.2` chart with its only declared
dependency, `redis-ha@4.34.11`, vendored as source under `charts/redis-ha`.
Its dependency repository is deliberately a local `file://` path, so both
Helm dependency resolution and manifest rendering work without a network
connection. Provenance and checksums are in `charts/argo-cd/VENDOR-METADATA.yaml`.

Do not replace the generated `Chart.lock` with the upstream lock file: the
vendor lock intentionally records the local dependency path.

## Application update

Merge `argocd-application-source-and-safety-patch.yaml` into the existing
Argo CD `Application` after copying this directory to the GitOps repository
root. It retains the values file at
`deployments/aws/dev/zora-apps/argocd/values.yaml` through a `$values`
reference and switches the chart source to the private Git path.

The patch intentionally specifies `syncPolicy: {}`. Apply it as a reviewed
Git change, refresh Argo CD, inspect the rendered diff, and run a manual sync.
Do not enable automatic pruning or self-heal until the new self-managed release
is healthy. This bundle does not modify a cluster or the currently running
Argo CD installation.
